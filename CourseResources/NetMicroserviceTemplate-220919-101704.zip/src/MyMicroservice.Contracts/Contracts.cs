using System;

namespace MyMicroservice.Contracts
{
    public record ItemCreated(
        Guid ItemId,
        string Name,
        string Description,
        decimal Price);

    public record ItemUpdated(
        Guid ItemId,
        string Name,
        string Description,
        decimal Price);

    public record ItemDeleted(Guid ItemId);
}