using MyMicroservice.Service.Dtos;
using MyMicroservice.Service.Entities;

namespace MyMicroservice.Service
{
    public static class Extensions
    {
        public static ItemDto AsDto(this Item item)
        {
            return new ItemDto(item.Id, item.Name, item.Description, item.Price, item.CreatedDate);
        }
    }
}