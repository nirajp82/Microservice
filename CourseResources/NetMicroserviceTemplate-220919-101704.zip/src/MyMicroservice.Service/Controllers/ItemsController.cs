using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Threading.Tasks;
using MassTransit;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using MyMicroservice.Contracts;
using MyMicroservice.Service.Dtos;
using MyMicroservice.Service.Entities;
using Casal.Microservice.Common;
using Casal.Microservice.Common.Settings;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;

namespace MyMicroservice.Service.Controllers
{
    [ApiController]
    [Route("items")]
    public class ItemsController : ControllerBase
    {
        private readonly IRepository<Item> itemsRepository;
        private readonly IPublishEndpoint publishEndpoint;
        private readonly Counter<int> counter;
        private readonly ILogger<ItemsController> logger;

        public ItemsController(
            IRepository<Item> itemsRepository,
            IPublishEndpoint publishEndpoint,
            IConfiguration configuration,
            ILogger<ItemsController> logger)
        {
            this.itemsRepository = itemsRepository;
            this.publishEndpoint = publishEndpoint;
            var settings = configuration.GetSection(nameof(ServiceSettings)).Get<ServiceSettings>();
            Meter meter = new(settings.ServiceName);
            counter = meter.CreateCounter<int>("ItemUpdated");
            this.logger = logger;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<ItemDto>>> GetAsync()
        {
            var items = (await itemsRepository.GetAllAsync())
                        .Select(item => item.AsDto());

            return Ok(items);
        }

        // GET /items/{id}
        [HttpGet("{id}")]
        public async Task<ActionResult<ItemDto>> GetByIdAsync(Guid id)
        {
            var item = await itemsRepository.GetAsync(id);

            if (item == null)
            {
                return NotFound();
            }

            return item.AsDto();
        }

        // POST /items
        [HttpPost]
        public async Task<ActionResult<ItemDto>> PostAsync(CreateItemDto createItemDto)
        {
            var item = new Item
            {
                Name = createItemDto.Name,
                Description = createItemDto.Description,
                Price = createItemDto.Price,
                CreatedDate = DateTimeOffset.UtcNow
            };

            logger.LogInformation(
                "Creating item {ItemName} with price {ItemPrice}...",
                item.Name,
                item.Price);

            await itemsRepository.CreateAsync(item);

            await publishEndpoint.Publish(new ItemCreated(
                item.Id,
                item.Name,
                item.Description,
                item.Price));

            return CreatedAtAction(nameof(GetByIdAsync), new { id = item.Id }, item);
        }

        // PUT /items/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> PutAsync(Guid id, UpdateItemDto updateItemDto)
        {
            var existingItem = await itemsRepository.GetAsync(id);

            logger.LogInformation(
                "Updating item with id '{ItemId}'...",
                existingItem.Id);

            if (existingItem == null)
            {
                return NotFound();
            }

            existingItem.Name = updateItemDto.Name;
            existingItem.Description = updateItemDto.Description;
            existingItem.Price = updateItemDto.Price;

            await itemsRepository.UpdateAsync(existingItem);

            await publishEndpoint.Publish(new ItemUpdated(
                existingItem.Id,
                existingItem.Name,
                existingItem.Description,
                existingItem.Price));

            counter.Add(1, new KeyValuePair<string, object>(nameof(existingItem.Name), existingItem.Name));

            return NoContent();
        }

        // DELETE /items/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAsync(Guid id)
        {
            var item = await itemsRepository.GetAsync(id);

            logger.LogInformation(
                "Deleting item with id '{ItemId}'...",
                item.Id);

            if (item == null)
            {
                return NotFound();
            }

            await itemsRepository.RemoveAsync(item.Id);

            await publishEndpoint.Publish(new ItemDeleted(id));

            return NoContent();
        }
    }
}