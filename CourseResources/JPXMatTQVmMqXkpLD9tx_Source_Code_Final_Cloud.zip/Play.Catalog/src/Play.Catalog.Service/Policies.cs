namespace Play.Catalog.Service
{
    public static class Policies
    {
        public const string Read = "read_access";
        public const string Write = "write_access";
    }
}