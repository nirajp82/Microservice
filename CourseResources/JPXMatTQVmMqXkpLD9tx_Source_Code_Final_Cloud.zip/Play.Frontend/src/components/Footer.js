import React, { Component } from 'react';

export class Footer extends Component {
  render() {
    return (
      <footer className="footer border-top text-muted">
        <div className="container">
          &copy; 2021 - Play Economy
        </div>
      </footer>
    );
  }
}
