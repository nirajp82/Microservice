namespace Play.Common.Settings
{
    public class RabbitMQSettings
    {
        public string Host { get; init; }
    }
}