namespace Play.Common.Settings
{
    public class ServiceBusSettings
    {
        public string ConnectionString { get; init; }
    }
}